<template>
  <div id="m-hello">
    <textarea id="m-textarea" v-model="textarea"></textarea>
    <div id="m-button">
      <button @click="onClean">クリア</button>
      <button @click="onSpeechRecognizer">音声認識</button>
    </div>
  </div>
</template>

<script>
import {onBeforeUnmount, onMounted, ref} from "vue";

export default {
  name: 'HelloWorld',
  setup() {
    const textarea = ref("");
    function isChatReady() {
      return true;
    }
    function sendChatMessage(msg) {
      textarea.value += msg + "\n"
      return true;
    }
    function onClean() {
      textarea.value = ""
    }
    function onSpeechRecognizer() {
      try {
        // eslint-disable-next-line no-undef
        native.startSpeechRecognizer()
      } catch (e) {
        // 実施 SpeechRecognizer 失敗 ...
      }
    }
    onMounted(() => {
      // 重要！！！！！この二つのAPIをNativeアプリに提供します！！！！
      window.isChatReady = isChatReady;
      window.sendChatMessage = sendChatMessage;
    })
    onBeforeUnmount(() => {
      window.isChatReady = undefined
      window.sendChatMessage = undefined
    })
    return {
      textarea,
      onClean,
      onSpeechRecognizer
    }
  }
}
</script>

<style scoped>
#m-hello {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}
#m-textarea {
  width: 500px;
  height: 300px;
  margin: 10px;
}
#m-button {
  width: 500px;
  display: flex;
  justify-content: space-around;
  align-items: center;
}
</style>
