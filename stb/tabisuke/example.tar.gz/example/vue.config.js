module.exports = {
    publicPath: process.env.NODE_ENV === 'development' ? './' : '/example/',
    outputDir: 'dist'
}
